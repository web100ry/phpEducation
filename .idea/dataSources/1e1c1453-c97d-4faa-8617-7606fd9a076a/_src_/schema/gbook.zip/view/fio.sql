CREATE VIEW gbook.fio AS
  SELECT
    `gbook`.`msgs`.`name`                            AS `name`,
    `gbook`.`msgs`.`email`                           AS `email`,
    (`gbook`.`msgs`.`name` + `gbook`.`msgs`.`email`) AS `value`
  FROM `gbook`.`msgs`;
