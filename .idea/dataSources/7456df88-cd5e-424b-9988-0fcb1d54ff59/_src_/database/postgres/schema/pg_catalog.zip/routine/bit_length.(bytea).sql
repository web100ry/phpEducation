create function pg_catalog.bit_length(bytea) returns integer
LANGUAGE SQL
AS $$
select pg_catalog.octet_length($1) * 8
$$;
